const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

// Serve the static HTML form
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'sampleForm.html'));
});

// Handle form submission and display the submitted data
app.post('/submit', (req, res) => {
    const formData = req.body;
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Form Submitted</title>
        </head>
        <body>
            <h1>Form Submitted Successfully!</h1>
            <p><strong>Member ID:</strong> ${formData.memberId}</p>
            <p><strong>Fullname:</strong> ${formData.fullName}</p>
            <p><strong>Gender:</strong> ${formData.gender}</p>
            <p><strong>Status:</strong> ${formData.status}</p>
            <p><strong>Religion:</strong> ${formData.religion}</p>
            <p><strong>Citizenship:</strong> ${formData.citizenship}</p>
            <p><strong>Type of Membership:</strong> ${formData.membershipType}</p>
            <p><strong>Year of Membership:</strong> ${formData.yearOfMembership}</p>
            <p><strong>School Affiliated:</strong> ${formData.schoolAffiliated}</p>
            <p><strong>Interest:</strong> ${Array.isArray(formData.interest) ? formData.interest.join(', ') : formData.interest}</p>
            <a href="/">Go back to the form</a>
        </body>
        </html>
    `);
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
